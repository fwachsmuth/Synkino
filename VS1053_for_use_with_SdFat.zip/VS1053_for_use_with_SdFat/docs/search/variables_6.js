var searchData=
[
  ['voll',['VolL',['../classvs1053.html#a133de5cd0dfb057d4ba9fc38ccff25a5',1,'vs1053']]],
  ['volr',['VolR',['../classvs1053.html#a2a5959f92fbb673945f5369878dc8aa5',1,'vs1053']]]
];
