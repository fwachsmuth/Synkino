var searchData=
[
  ['none',['none',['../vs1053___sd_fat_8h.html#ad701087b7fa2b683f9da6cdb04c9ecbfab7e4e0120a041dbe6528b050c04269e0',1,'vs1053_SdFat.h']]]
];
