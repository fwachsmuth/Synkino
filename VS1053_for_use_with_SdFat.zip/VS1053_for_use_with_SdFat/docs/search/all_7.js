var searchData=
[
  ['initialized',['initialized',['../vs1053___sd_fat_8h.html#a1e43f52ed18e725e71477e654c74de73a93eb25c13efc03a01d4d136099217a33',1,'vs1053_SdFat.h']]],
  ['isfnmusic',['isFnMusic',['../vs1053___sd_fat_8cpp.html#a71871e135b8b08ea601a3302fa4bbe91',1,'isFnMusic(char *filename):&#160;vs1053_SdFat.cpp'],['../vs1053___sd_fat_8h.html#aad4b5cd60700c37983748a6aa387f7f1',1,'isFnMusic(char *):&#160;vs1053_SdFat.cpp']]],
  ['isplaying',['isPlaying',['../classvs1053.html#a5a1680ba0e7ace0d0cde9f8457ba27e5',1,'vs1053']]]
];
