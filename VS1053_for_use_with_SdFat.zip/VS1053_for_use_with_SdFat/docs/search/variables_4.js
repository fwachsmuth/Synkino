var searchData=
[
  ['sd',['sd',['../vs1053___sd_fat_8h.html#a15e6b7e1f0fb2d1e0fe1654721bb5302',1,'vs1053_SdFat.h']]],
  ['singlemidinotefile',['SingleMIDInoteFile',['../vs1053___sd_fat_8cpp.html#ac80debdbadbcad59d56c2a750486683e',1,'vs1053_SdFat.cpp']]],
  ['spi_5fread_5frate',['spi_Read_Rate',['../classvs1053.html#a9cdbd264bf10d3e51296935cbf583996',1,'vs1053']]],
  ['spi_5fwrite_5frate',['spi_Write_Rate',['../classvs1053.html#a1574cc4b13b53d9ad0d67951fe8bf409',1,'vs1053']]],
  ['start_5fof_5fmusic',['start_of_music',['../classvs1053.html#ad4224c0ea43c70bfb2b118f82323d4c6',1,'vs1053']]]
];
