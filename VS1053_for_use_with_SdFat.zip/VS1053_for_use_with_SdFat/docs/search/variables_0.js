var searchData=
[
  ['bass_5famplitude',['Bass_Amplitude',['../unionvs1053_1_1sci__bass__m.html#a0166b2295b2ffcef0a5bb070008a4297',1,'vs1053::sci_bass_m']]],
  ['bass_5ffreqlimt',['Bass_Freqlimt',['../unionvs1053_1_1sci__bass__m.html#a60870a751b5d5097c58ad766693a4f12',1,'vs1053::sci_bass_m']]],
  ['bitrate',['bitrate',['../classvs1053.html#a74803e7372e1db4ab1544b8f0254476f',1,'vs1053']]],
  ['byte',['byte',['../uniontwobyte.html#a96a809c17262b7e7ebc6f0fb790de593',1,'twobyte']]]
];
