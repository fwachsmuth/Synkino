var searchData=
[
  ['pausedatastream',['pauseDataStream',['../classvs1053.html#acd2ef01ff86cd66e8faf0d10a581736c',1,'vs1053']]],
  ['pausemusic',['pauseMusic',['../classvs1053.html#ae889fb78f3c56b2cfeee39a5f2b6cd3b',1,'vs1053']]],
  ['playmp3',['playMP3',['../classvs1053.html#a5a58e7aa856216cf8d4edf1abad8ed6a',1,'vs1053']]],
  ['playtrack',['playTrack',['../classvs1053.html#a627ec2b19a3a120bbbd34eb1b1e09d6f',1,'vs1053']]]
];
