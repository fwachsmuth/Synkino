var searchData=
[
  ['sendsinglemidinote',['SendSingleMIDInote',['../classvs1053.html#a661c9ae92aa944be4f19704553b393c0',1,'vs1053']]],
  ['setbassamplitude',['setBassAmplitude',['../classvs1053.html#aa5c6cce473a4f73273bfcc63f8ce28c9',1,'vs1053']]],
  ['setbassfrequency',['setBassFrequency',['../classvs1053.html#a34fa69d7e5c7fe1120b59cc527cd4a27',1,'vs1053']]],
  ['setbitrate',['setBitRate',['../classvs1053.html#a4dd659d23ff073b206317c37105efb9a',1,'vs1053']]],
  ['setdifferentialoutput',['setDifferentialOutput',['../classvs1053.html#a13eff82f98c6ff7180985a79c2fde65e',1,'vs1053']]],
  ['setearspeaker',['setEarSpeaker',['../classvs1053.html#a6456ee3b9fcd95059d65c46266f78d65',1,'vs1053']]],
  ['setmonomode',['setMonoMode',['../classvs1053.html#ad09847bd739d981d5da49d2de24c1394',1,'vs1053']]],
  ['setplayspeed',['setPlaySpeed',['../classvs1053.html#ad1e5d47c1facb70f3354d39d160a8af6',1,'vs1053']]],
  ['settrebleamplitude',['setTrebleAmplitude',['../classvs1053.html#ab0e4385f4e5bc7509c5ae6c2743e87e2',1,'vs1053']]],
  ['settreblefrequency',['setTrebleFrequency',['../classvs1053.html#a7e8c784cd569d9de0ff4f9e4f0400e1e',1,'vs1053']]],
  ['setvolume',['setVolume',['../classvs1053.html#aa85cf76a3ec14f4e5681e032dd25e15d',1,'vs1053::setVolume(uint8_t, uint8_t)'],['../classvs1053.html#a4dbdf77ad7635b568c5d39c17e2a3ff0',1,'vs1053::setVolume(uint16_t)'],['../classvs1053.html#adba0d615de4fa8fcadd5e27e3dc63b26',1,'vs1053::setVolume(uint8_t)']]],
  ['setvumeter',['setVUmeter',['../classvs1053.html#a6822fe36437d64c4dce20c8209de20c7',1,'vs1053']]],
  ['skip',['skip',['../classvs1053.html#af1d76c4afa247e0f85a3dc7e020903dd',1,'vs1053']]],
  ['skipto',['skipTo',['../classvs1053.html#a54f04077f07d821f387731f292a0a7a5',1,'vs1053']]],
  ['spiinit',['spiInit',['../classvs1053.html#a0ba3fe387ef837b7ef0ecc93069c9983',1,'vs1053']]],
  ['stoptrack',['stopTrack',['../classvs1053.html#a4a2241d3ed9cdc62a10a00d09d8b5f3f',1,'vs1053']]],
  ['strip_5fnonalpha_5finplace',['strip_nonalpha_inplace',['../vs1053___sd_fat_8cpp.html#a9ff77b026d5d353ff902b4787e8589aa',1,'strip_nonalpha_inplace(char *s):&#160;vs1053_SdFat.cpp'],['../vs1053___sd_fat_8h.html#a9ff77b026d5d353ff902b4787e8589aa',1,'strip_nonalpha_inplace(char *s):&#160;vs1053_SdFat.cpp']]]
];
