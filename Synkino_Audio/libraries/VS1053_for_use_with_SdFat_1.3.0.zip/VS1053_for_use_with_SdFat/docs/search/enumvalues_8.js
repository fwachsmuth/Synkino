var searchData=
[
  ['uninitialized',['uninitialized',['../vs1053___sd_fat_8h.html#a1e43f52ed18e725e71477e654c74de73a8a255517f392ea86c344d3dd92164b3d',1,'vs1053_SdFat.h']]]
];
