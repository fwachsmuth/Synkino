var searchData=
[
  ['dcs_5fhigh',['dcs_high',['../classvs1053.html#a257bf188529287219572a69757ebb4f4',1,'vs1053']]],
  ['dcs_5flow',['dcs_low',['../classvs1053.html#a11ca91f18aa76ee9d4305f5434a0e8ff',1,'vs1053']]],
  ['disablerefill',['disableRefill',['../classvs1053.html#ad83f1e449ff548432e15bd48888797b8',1,'vs1053']]],
  ['disabletestsinewave',['disableTestSineWave',['../classvs1053.html#a38d8b7e7c7d418999ec752716c982d41',1,'vs1053']]]
];
