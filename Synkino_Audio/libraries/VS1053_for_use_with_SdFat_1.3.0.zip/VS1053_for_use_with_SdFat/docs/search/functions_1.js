var searchData=
[
  ['begin',['begin',['../classvs1053.html#a50fda27cb31f6b39c0d2224e67c8c5d3',1,'vs1053']]]
];
