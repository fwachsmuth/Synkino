var searchData=
[
  ['deactivated',['deactivated',['../vs1053___sd_fat_8h.html#a1e43f52ed18e725e71477e654c74de73a10a85fc0c5a47b51ab99159cfef7b773',1,'vs1053_SdFat.h']]]
];
